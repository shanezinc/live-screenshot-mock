const BASE_PATH = "/live-screenshot-mock/"
const CACHE_PREFIX = "live-screenshot-mock-path-%2Flive-screenshot-mock%2F:"
const CACHE_NAME = CACHE_PREFIX + "3db4fbfe622550aadc47071c"
const SHELL_HASH = "9e00eb581453ce38b2697266624df23dda2610db01a876391d4eaa6f7343a6ef"
const ASSETS = new Set(["/live-screenshot-mock/assets/demo-live-CkdFPrE3.png","/live-screenshot-mock/assets/demo-summary-BsgbVD0Z.png","/live-screenshot-mock/assets/index-DbDL7iRh.css","/live-screenshot-mock/assets/index-XqwRghdh.js","/live-screenshot-mock/assets/live-1280-5QjD1Rva.png","/live-screenshot-mock/assets/summary-1320-BEUk_8Ss.png","/live-screenshot-mock/manifest.webmanifest","/live-screenshot-mock/icons/apple-touch-icon.png","/live-screenshot-mock/icons/icon-192.png","/live-screenshot-mock/icons/icon-512.png"])

async function verifyShell(response) {
  const body = await response.clone().arrayBuffer()
  const digest = await crypto.subtle.digest('SHA-256', body)
  const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('')
  if (hash !== SHELL_HASH) throw new Error('The deployed app shell changed during installation.')
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME)
    try {
      for (const path of [BASE_PATH, ...ASSETS]) {
        const request = new Request(path, { cache: 'reload', mode: 'same-origin', redirect: 'error' })
        const response = await fetch(request)
        const contentType = response.headers.get('content-type') ?? ''
        if (!response.ok || (path !== BASE_PATH && contentType.includes('text/html'))) {
          throw new Error(`Unable to cache application resource ${path}.`)
        }
        if (path === BASE_PATH) await verifyShell(response)
        await cache.put(path, response)
      }
    } catch (error) {
      await caches.delete(CACHE_NAME)
      throw error
    }
    // The browser activates updates only after existing controlled views close.
  })())
})

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys()
    await Promise.all(keys
      .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
      .map((key) => caches.delete(key)))
    await self.clients.claim()
  })())
})

async function fromShellCache(path) {
  const cache = await caches.open(CACHE_NAME)
  return cache.match(path)
}

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET') return
  const url = new URL(request.url)
  if (url.protocol !== self.location.protocol || url.origin !== self.location.origin || url.search) return
  if (request.mode === 'navigate' && url.pathname === BASE_PATH) {
    // Honor upstream sign-in and denial responses. Only loss of network opens the offline shell.
    event.respondWith(fetch(request).catch(async (error) => {
      const cached = await fromShellCache(BASE_PATH)
      if (cached) return cached
      throw error
    }))
  } else if (ASSETS.has(url.pathname)) {
    event.respondWith(fromShellCache(url.pathname).then((cached) => cached ?? fetch(request)))
  }
})
